title: MyBatis源码分析-XMl映射文件解析
date: '2019-09-27 22:29:56'
updated: '2019-09-27 22:29:56'
tags: [MyBatis]
permalink: /articles/2019/09/27/1569594596256.html
---
## 前言
&emsp;&emsp;在MyBatis初始化时，除了加载mybatis-config.xml配置文件还会加载全部的映射配置文件，可以在mybatis-config.xml配置文件中<mapper>获取配置文件位置以及使用了配置了注解标识的接口，使用XMLMapperBuilder对象解析XML映射文件，如果映射配置文件存在相应的Mapper接口，也会加载相应的Mapper接口，并使用MapperAnnotationBuilder对象解析其中的注解并完成向MapperRegister注册。<mapper>节点指定xml文件有四种方式:
   * package方式: 指定Mapper接口所在包，可以使用注解模式。在非注解模式的情况下，xml映射配置文件和Mapper接口需要在同一级目录下，并且名称相同
   * resource方式: 指定xml映射文件路径，不可以使用注解模式。xml映射文件和Mapper接口可以分开存放
   * class方式: 指定Mapper接口路径，可以使用注解模式。非注解模式的情况下，xml文件和Mapper接口需要在同一级目录下，且名称相同
   * url方式: 执行xml映射文件远程路径，不可以使用注解模式。xml映射文件和Mapper接口可以分开存在

通过调用XMLConfigBuilder.mapperElement解析mappers节点，具体实现代码如下: 
```
    private void mapperElement(XNode parent) throws Exception {
        if (parent != null) {
            Iterator var2 = parent.getChildren().iterator();
            while(true) {
                while(var2.hasNext()) {
                    XNode child = (XNode)var2.next();
                    String resource;
                    if ("package".equals(child.getName())) {
                        // package 方式，MapperRegister.addMapper中会创建MapperAnnotationBuilder对象解析Mapper口中的注解和xml文件
                        resource = child.getStringAttribute("name");
                        this.configuration.addMappers(resource);
                    } else {
                        ......
                        if (resource != null && url == null && mapperClass == null) {
                            // resource 方式
                            ......
                            mapperParser = new XMLMapperBuilder(inputStream, this.configuration, resource, this.configuration.getSqlFragments());
                            mapperParser.parse();
                        } else if (resource == null && url != null && mapperClass == null) {
                            // url 方式
                            .......
                            mapperParser = new XMLMapperBuilder(inputStream, this.configuration, url, this.configuration.getSqlFragments());
                            mapperParser.parse();
                        } else {
                            // class 方式，MapperRegister.addMapper中会创建MapperAnnotationBuilder对象解析Mapper口中的注解和xml文件
                            .......
                            this.configuration.addMapper(mapperInterface);
                        }
                    }
                }
                return;
            }
        }
  
```
## XML映射文件解析
### XMLConfigBuilder
&emsp;&emsp;XMLConfigBuilder负责解析映射配置文件，继承了BaseBuilder抽象类，调用parse()方法是进行XML映射配置文件解析，在XMLConfigBuilder解析过程中，每个节点的解析过程被封装成了各个方法，并将解析数据保存到Configuration中，通过在configurationElement方法中调用，具体代码如下: 
```
    public void parse() {
        // 判断是否已经加载过该映射文件
        if (!this.configuration.isResourceLoaded(this.resource)) {
            // 解析<mapper>节点，判断命名空间是存在，不存在抛出异常，并解析各个子节点，如<resultMap>，<cache>等
            this.configurationElement(this.parser.evalNode("/mapper"));
            // 将resource添加到Configuration.loadedResource集合中，记录已加载过的映射文件
            this.configuration.addLoadedResource(this.resource);
            // 根据namespace属性值获取Mapper接口解析其方法上的注解并向MapperRegister注册
            this.bindMapperForNamespace();
        }
        // 处理configurationElement方法中解析失败的<resultMap>节点
        this.parsePendingResultMaps();
        // 处理configurationElement方法中解析失败的<cache-ref>节点
        this.parsePendingCacheRefs();
        // 处理configurationElement方法中解析失败的SQL语句节点
        this.parsePendingStatements();
    }
```
#### cache节点解析
&emsp;&emsp;MyBatis拥有非常强大的二级缓存功能，默认情况下时没有开启二级缓存的，如果要以某命名空间开启二级缓存功能，则需要在相应的映射配置文件中添加cache节点或者cacheRef节点指定一个已存在的缓存，详情见[MyBatis源码分析-缓存模块](http://www.raocloud.cn/articles/2019/09/27/1569567839562.html 'MyBatis源码分析-缓存模块')。XMlMapperBuilder.cacheElement方法主要解析cache节点，具体实现代码如下:

```
    private void cacheElement(XNode context) {
        if (context != null) {
            // 获取type属性，默认值为PERPETUAL，并查找type属性值对应的Cache接口实现
            String type = context.getStringAttribute("type", "PERPETUAL");
            Class<? extends Cache> typeClass = this.typeAliasRegistry.resolveAlias(type);
            // 获取eviction属性，默认值为LRU，并获取eviction属性值对应的装饰器，为type属性对应的实现提供装饰
            String eviction = context.getStringAttribute("eviction", "LRU");
            Class<? extends Cache> evictionClass = this.typeAliasRegistry.resolveAlias(eviction);
            Long flushInterval = context.getLongAttribute("flushInterval");
            Integer size = context.getIntAttribute("size");
            boolean readWrite = !context.getBooleanAttribute("readOnly", false);
            boolean blocking = context.getBooleanAttribute("blocking", false);
            // 获取节点下的子节点<property>，将用于初始化二级缓存，如自定义的Cache接口实现，通过<property>设置缓存文件路径
            Properties props = context.getChildrenAsProperties();
            // 通过MapperBuilderAssistant辅助类创建Cache对象，添加到Configuration.caches
            this.builderAssistant.useNewCache(typeClass, evictionClass, flushInterval, size, readWrite, blocking, props);
        }
    }
```
&emsp;&emsp;MapperBuilderAssistant.userNewCache方法用来创建cache对象和将Cache对象保存到Configuration.caches中，其中Cache对象使用CacheBuilder根据配置属性创建，Configuration.caches属性类型为StrictMap，其继承了HashMap并在其基础上了做了修改，put时对检测到重复KEY则抛出异常，get时对检测到不存在的和产生二义性的key则抛出异常，具体实现自行查看源码，其中userNewCache具体实现如下:
```
    public Cache useNewCache(Class<? extends Cache> typeClass, Class<? extends Cache> evictionClass, 
					    Long flushInterval, Integer size, boolean readWrite, boolean blocking, Properties props) {
	// CacheBuilder根据配置属性创建Cache对象
        Cache cache = (new CacheBuilder(this.currentNamespace)).implementation((Class)this.valueOrDefault(typeClass, PerpetualCache.class))
		.addDecorator((Class)this.valueOrDefault(evictionClass, LruCache.class))
		.clearInterval(flushInterval)
		.size(size)
		.readWrite(readWrite)
		.blocking(blocking)
		.properties(props).build();
	// 将Cache保存到Configuration.caches
        this.configuration.addCache(cache);
        this.currentCache = cache;
        return cache;
    }
```
CacheBuilder是Cache的建造者，其通过builder创建Cache对象并添加合适的装饰器，具体实现代码如下:
```
    // Cache对象唯一的标识，一般情况下对应映射文件中设置的namespace  
    private final String id;  
    // Cache接口的真正实现类，默认值为PerpetualCache.class  
    private Class<? extends Cache> implementation;  
    // 装饰器集合，默认只包含LruCache.class  
    private final List<Class<? extends Cache>> decorators;  
    private Integer size;  
    // 清理周期  
    private Long clearInterval;  
    // 是否可读写  
    private boolean readWrite;  
    // 是否阻塞  
    private boolean blocking;  
    // 其他配置信息  
    private Properties properties;

    public Cache build() {
        // 如果implementation字段和decorators字段为空，则设置为默认值
        this.setDefaultImplementations();
        // 通过反射方式创建Cache对象
        Cache cache = this.newBaseCacheInstance(this.implementation, this.id);
        // 根据<cache>下的<property>节点初始化Cache对象
        this.setCacheProperties((Cache)cache);
        // Cache对象类型为PerpetualCache，则为其遍历添加decorators集合中的装饰器
        // 如果是自定义类型的Cache接口实现，则不添加decorators集合中的装饰器
        if (PerpetualCache.class.equals(cache.getClass())) {
            Iterator var2 = this.decorators.iterator();

            while(var2.hasNext()) {
                // 通过反射获取参数为Cache类型的构造方法，并通过该构造方法创建装饰器
                Class<? extends Cache> decorator = (Class)var2.next();
                cache = this.newCacheDecoratorInstance(decorator, (Cache)cache);
                // 配置cache对象属性
                this.setCacheProperties((Cache)cache);
            }

            cache = this.setStandardDecorators((Cache)cache);
        } else if (!LoggingCache.class.isAssignableFrom(cache.getClass())) {
            // 如果不是LoggingCache的子类，则添加LoggingCache装饰器
            cache = new LoggingCache((Cache)cache);
        }

        return (Cache)cache;
    }
```
