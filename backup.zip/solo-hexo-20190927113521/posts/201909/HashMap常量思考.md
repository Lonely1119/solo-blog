title: HashMap常量思考
date: '2019-09-24 14:17:59'
updated: '2019-09-27 11:19:37'
tags: [java]
permalink: /articles/2019/09/24/1569305879380.html
---
![](https://img.hacpai.com/bing/20181108.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 为什么容量大小定义为2的幂次方
    /**
     * The default initial capacity - MUST be a power of two.
     */
    static final int DEFAULT_INITIAL_CAPACITY = 1 << 4; 

    数组下标索引定位公式: i = (n - 1) & hash
&emsp;&emsp;当容量大小n为2的幂次方时，(n-1)&hash等价于hash%n，而hash%n相当于hash-(hash/n)*n，这样做的目的是因为与运算比取余运算的效率要高，同时(n-1)的二进制全1，那么计算索引下标的结果值就完全只依赖于KEY的hashcode，而不需要依赖于容量大小，使得元素的分布有一个可控性。
例如：
  * 1.计算book的hashcode，结果为十进制的3029737，二进制的101110001110101110 1001
  * 假定HashMap长度是默认的16，计算Length-1的结果为十进制的15，二进制的1111
  * 把以上两个结果做与运算，101110001110101110 1001 & 1111 = 1001，十进制是9，所以index=9

可以说，Hash算法最终得到的index结果，完全取决于Key的Hashcode值的最后几位

### 加载因子为什么是0.75，为什么不是0.5或者1

    /**
     * The load factor used when none specified in constructor.
     */
    static final float DEFAULT_LOAD_FACTOR = 0.75f;
&emsp;&emsp;如果是0.5，那么每次达到扩容的的一半就进行扩容，默认容量是16，达到8就扩容成32，达到16就扩容成64，最终使用空间和未使用空间的差值就会逐渐增加，空间利用率低。如果是1，那意味着每次空间使用完毕才扩容，在一定程度上增加put操作的时间

官方文档说明:
    
    As a general rule, the default load factor (.75) offers a good tradeoff between time and space costs. 
    Higher values decrease the space overhead but increase the lookup cost (reflected in most of the operations 
    of the HashMap class, including get and put). The expected number of entries in the map and its load factor 
    should be taken into account when setting its initial capacity, so as to minimize the number of rehash 
    operations. If the initial capacity is greater than the maximum number of entries divided by the load factor,
    no rehash operations will ever occur.
    
    所谓一般规则，默认负载因子(0.75)在时间和空间成本上提供了很好的折衷。较高的值会降低空间开销，但提高了查找成本(体现在大多数的HashMap类的操作，包括get	和put)。设置初始大小时，应该考虑映射中entry条目数以及加载因子，并且尽量减少rehash操作次数。如果初始容量大于最大数目数除以负载因子，rehash操作将不会发生

解析：https://stackoverflow.com/questions/10901752/what-is-the-significance-of-load-factor-in-hashmap

### 为什么最大容量大小为1 << 30，而不是1 << 31

    /**
     * The maximum capacity, used if a higher value is implicitly specified
     * by either of the constructors with arguments.
     * MUST be a power of two <= 1<<30.
     */
    static final int MAXIMUM_CAPACITY = 1 << 30;
&emsp;&emsp;int类型占4个字节，一个字节占8个位，所以最多32位。按理说最大数可以向左移动31位即2的31次幂，实际二进制的最左边那一位是符号位，用来表示正负。
    
    System.out.println(1 << 30); // 1073741824
    System.out.println(1 << 31); // -2147483648
    System.out.println(1 << 32); // 1
    System.out.println(1 << 33); // 2

### 为什么转换红黑数的阈值为8? 转换链表的阈值为6? 最小树形化桶容量大小为64

    /**
     * The bin count threshold for using a tree rather than list for a
     * bin.  Bins are converted to trees when adding an element to a
     * bin with at least this many nodes. The value must be greater
     * than 2 and should be at least 8 to mesh with assumptions in
     * tree removal about conversion back to plain bins upon
     * shrinkage.
     */
    static final int TREEIFY_THRESHOLD = 8;
    
    /**
     * The bin count threshold for untreeifying a (split) bin during a
     * resize operation. Should be less than TREEIFY_THRESHOLD, and at
     * most 6 to mesh with shrinkage detection under removal.
     */
    static final int UNTREEIFY_THRESHOLD = 6;
    
    /**
     * The smallest table capacity for which bins may be treeified.
     * (Otherwise the table is resized if too many nodes in a bin.)
     * Should be at least 4 * TREEIFY_THRESHOLD to avoid conflicts
     * between resizing and treeification thresholds.
     */
    static final int MIN_TREEIFY_CAPACITY = 64;
    
&emsp;&emsp;JDK8及以后版本，HashMap底层数据结构引入了红黑树。当添加元素时，如果桶中元素大于8并且桶个数大于64时，会自动转化为红黑数。当桶中元素小于6时红黑树会退化为链表结构。以下是源码中解释：
    
    Ideally, under random hashCodes, the frequency of
    nodes in bins follows a Poisson distribution
    (http://en.wikipedia.org/wiki/Poisson_distribution) with a
    parameter of about 0.5 on average for the default resizing
    threshold of 0.75, although with a large variance because of
    resizing granularity. Ignoring variance, the expected
    occurrences of list size k are (exp(-0.5) * pow(0.5, k) /
    factorial(k)). The first values are:
    
    0:    0.60653066
    1:    0.30326533
    2:    0.07581633
    3:    0.01263606
    4:    0.00157952
    5:    0.00015795
    6:    0.00001316
    7:    0.00000094
    8:    0.00000006
&emsp;&emsp;当hashcode离散型比较好的时候，树形化的概念非常小，因为数据均匀分布在每个桶中，几乎不会有桶中的链表长度达到阈值。但是在随机的hashcode情况下，离散型可能变得非常的差，然后JDK又不能阻止用户实现这种不好的hash算法，因此可能导致不均匀的数据分。理想状态下，随机哈希码情况下，对于默认0.75的加载因子，桶中节点的分布频率服从参数为0.5的泊松分布。由对照表，可以看到链表中元素个数为8时概率非常小，所以链表转换红黑树选择了8。再看元素个数为6相对与7或者8时的概率相差两个数量级，考虑到红黑树是一颗自平衡二叉树，当添加/删除元素时，为维持红黑树特性会进行左旋和右旋操作，是一个非常耗时的操作，所以红黑树转化为链表选择了6。并且在树形化时桶的数量需要大于64，防止桶容量过小而导致链表长度过长，对于这种原因的产生的长链表，应该优先考虑选择扩容而避免不必要的树化。

### 参考
https://juejin.im/post/5d7195f9f265da03a6533942
