title: JWT理论
date: '2019-09-24 18:05:40'
updated: '2019-09-27 11:19:14'
tags: [spring-security]
permalink: /articles/2019/09/24/1569319539938.html
---
![](https://img.hacpai.com/bing/20181104.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 数据结构
&emsp;&emsp;JWT由三段信息构成，分别为头部(header)、载荷(payload)、签证(signature)，将这三段信息文件用.连接一起就构成JWT字符串，如下:

    eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiYWRtaW4iOnRydWV9.TJVA95OrM7E2cBab30RMHrHDcEfxjoYZgeFONFh7HgQ
#### Header
&emsp;&emsp;Header部分是一个JSON对象，描述JWT的元数据，承载两部分信息：
   * 声明令牌类型，这里是jwt
   * 声明签名的算法，默认为HMAC SHA256

完整的头部就想如下JSON:

    {
        'typ' : 'jwt',
        'alg' : 'HS256'
    }

    Base64编码后: eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9

#### Payload
&emsp;&emsp;PayLoad部分也是一个JSON对象，用来存放实际需要传递的数据。JWT规定了7个官方声明字段供使用:

    * iss(issuer): JWT签发人
    * exp(expiration time): 过期时间
    * sub(subject): JWT所面向的用户
    * aud(audience): 接收JWT的用户
    * nbf(not before): 定义在什么时间之前，该JWT都是不可用的
    * iat(issued at): JWT的签发时间
    * jti(jwt ID): JWT的唯一身份标识，主要用来作为一次性TOKEN，从而回避重放攻击

    Base64编码后: eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiYWRtaW4iOnRydWV9
注意：声明字段可以自定义；JWT默认是不加密的，任何人都可以读到，所以不要把秘密信息放在这个部分

#### Signature
&emsp;&emsp;Signature是一个对前两部分的签名信息，防止数据篡改，这个签证信息由三部分组成的：
   * Header(Base64编码后)
   * Payload(Base64编码后)
   * Secret

&emsp;&emsp;这个部分需要Base64编码后的Header和payload使用.连接成字符串组成的字符串，然后通过Header中声明的加密方式进行加盐secret组合加密

&emsp;&emsp;注意：Secret是保存在服务器端的，JWT的签发生成也是在服务器的，Secret就是用来进行JWT的签发和JWT的验证，所以他就是你服务端的私钥，在任何场景都不应该泄露出去。一旦客户端得知这个Secret，那就意味着客户端可以自我签发jwt

### 使用方式
&emsp;&emsp;客户端身份认证成功收到服务器返回的JWT，可以存储在Cookie里面，也可以存储在localStorage，在JWT有效期内，客户端每次与服务器通信，都要带上这个JWT。可以把它放在Cookie里面自动发送，但是这样不能进行跨域，所以通常放在HTTP请求的头部信息Authorization字段里面

    Authorization: Bearer <TOKEN>

### 总结
   * 因为JSON的通用性，所以JWT是可以跨语言支持的
   * 通过Payload可以在自身存储一些其他业务逻辑所必需的的非敏感信息
   * JWT的构成非常简单，字节占用很小，所有非常便于传输
   * 不需要在服务端保存会话信息，所以易于应用的扩展

参考：
    https://jwt.io/introduction/
