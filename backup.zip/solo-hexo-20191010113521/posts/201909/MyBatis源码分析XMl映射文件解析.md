title: MyBatis源码分析-XMl映射文件解析
date: '2019-09-27 22:29:56'
updated: '2019-10-10 10:32:24'
tags: [MyBatis]
permalink: /articles/2019/09/27/1569594596256.html
---
## 前言
&emsp;&emsp;在MyBatis初始化时，除了加载mybatis-config.xml配置文件还会加载全部的映射配置文件，可以在mybatis-config.xml配置文件的<mapper\>节点获取配置文件位置以及使用了配置了注解标识的接口，并使用XMLMapperBuilder对象解析XML映射文件，如果映射配置文件存在相应的Mapper接口，也会加载相应的Mapper接口，然后使用MapperAnnotationBuilder对象解析其中的注解完成向MapperRegister注册。<mapper\>指定xml文件位置有四种方式:
   * package方式: 指定Mapper接口所在包，可以使用注解模式。在非注解模式的情况下，xml映射配置文件和Mapper接口需要在同一级目录下，并且名称相同
   * resource方式: 指定xml映射文件路径，不可以使用注解模式。xml映射文件和Mapper接口可以分开存放
   * class方式: 指定Mapper接口路径，可以使用注解模式。非注解模式的情况下，xml文件和Mapper接口需要在同一级目录下，且名称相同
   * url方式: 执行xml映射文件远程路径，不可以使用注解模式。xml映射文件和Mapper接口可以分开存在

通过调用XMLConfigBuilder.mapperElement解析<mapper\>节点，具体实现代码如下: 
```
private void mapperElement(XNode parent) throws Exception {
    if (parent != null) {
        Iterator var2 = parent.getChildren().iterator();
        while(true) {
            while(var2.hasNext()) {
                XNode child = (XNode)var2.next();
                String resource;
                if ("package".equals(child.getName())) {
                    // package 方式，MapperRegister.addMapper中会创建MapperAnnotationBuilder对象解析Mapper口中的注解和xml文件
                    resource = child.getStringAttribute("name");
                    this.configuration.addMappers(resource);
                } else {
                    ......
                    if (resource != null && url == null && mapperClass == null) {
                        // resource 方式
                        ......
                        mapperParser = new XMLMapperBuilder(inputStream, this.configuration, resource, this.configuration.getSqlFragments());
                        mapperParser.parse();
                    } else if (resource == null && url != null && mapperClass == null) {
                        // url 方式
                        .......
                        mapperParser = new XMLMapperBuilder(inputStream, this.configuration, url, this.configuration.getSqlFragments());
                        mapperParser.parse();
                    } else {
                        // class 方式，MapperRegister.addMapper中会创建MapperAnnotationBuilder对象解析Mapper口中的注解和xml文件
                        .......
                        this.configuration.addMapper(mapperInterface);
                    }
                }
            }
            return;
        }
    }
}
```
## MapperBuilderAssistant
&emsp;&emsp;在分析XML映射文件解析过程之前，先介绍一下解析过程中用到的辅助类MapperBuilderAssistant，该类主要用于创建XML映射文件各个节点对应类的实例，并添加到Configuration中。具体核心方法如下:
```
// 通过CacheBuilder建造者创建Cache对象，并添加到Configuration.caches中，用于解析<cache\>节点时
public Cache useNewCache(Class<? extends Cache> typeClass, Class<? extends Cache> evictionClass, 
                Long flushInterval, Integer size, boolean readWrite, boolean blocking, Properties props)
                         
// 查找对应的Cache对象，不存在则抛出IncompleteElementException异常，用于解析<cache-ref\>节点时
public Cache useCacheRef(String namespace)

// 通过ResultMapping.Builder创建ResultMapping对象，并添加到Configuration.resultMaps中，用于解析<resultMap\>节点的子节点，如<id\>、<result\>等除了<discriminator\>节点
public ResultMapping buildResultMapping(Class<?> resultType, String property, String column, Class<?> javaType, 
                        JdbcType jdbcType, String nestedSelect, String nestedResultMap, String notNullColumn, 
                        String columnPrefix, Class<? extends TypeHandler<?>> typeHandler, List<ResultFlag> flags, 
                        String resultSet, String foreignColumn, boolean lazy) 

// 通过ResultMap.Builder创建ResultMap对象，并添加到Configuration.resultMaps中，用于解析<resultMap\>节点
// 如果extends属性值对应的ResultMapper对象不存在是则抛出IncompleteElementException异常
public ResultMap addResultMap(String id, Class<?> type, String extend, Discriminator discriminator, 
                    List<ResultMapping> resultMappings, Boolean autoMapping)
                    
// 通过Discriminator.Builder创建Discriminator对象，用于解析<discriminator\>节点，其有两个字段resultMapping和和discriminatorMap
// resultMappings: 类型为ResultMapping，<discriminator\>节点属性会封装到该字段中
// discriminatorMap: 类型为Map<String, String>，<discriminator\>子节点属性值会被
public Discriminator buildDiscriminator(Class<?> resultType, String column, Class<?> javaType, JdbcType jdbcType, 
                        Class<? extends TypeHandler<?>> typeHandler, Map<String, String> discriminatorMap)
```
## XMLMapperBuilder
&emsp;&emsp;XMLMapperBuilder继承了BaseBuilder抽象类，担任具体建造者角色，调用parse()方法是进行XML映射配置文件解析，在XMLMapperBuilder解析实现中，每个类型节点的解析过程被封装成了各个方法，并将解析数据保存到Configuration对应的属性中，具体代码如下: 
```
public void parse() {
    // 判断是否已经加载过该映射文件
    if (!this.configuration.isResourceLoaded(this.resource)) {
    	// 解析<mappers>节点，判断命名空间是存在，不存在抛出异常，并解析各个子节点，如<resultMap>，<cache>等
    	this.configurationElement(this.parser.evalNode("/mapper"));
   	// 将resource添加到Configuration.loadedResource集合中，记录已加载过的映射文件
    	this.configuration.addLoadedResource(this.resource);
    	// 根据namespace属性值获取Mapper接口解析其方法上的注解并向MapperRegister注册
    	this.bindMapperForNamespace();
    }
    /**
     * 解析失败的原因，可能是所依赖的信息并未解析
     */ 
   // 处理resultMapElement()方法中解析失败的<resultMap>节点
   // 在解析resultMap异常时，该节点信息会被保存在Configuration.incompleteResultMaps
   this.parsePendingResultMaps();
   // 处理cacheRefElement()方法中解析失败的<cache-ref>节点
   // 在解析cache-ref异常时，该节点信息会被保存在Configuration.incompleteCacheRefs
   this.parsePendingCacheRefs();
   // 处理buildStatementFromContext()方法中解析失败的SQL语句节点
   // 在解析SQL语句异常时，该节点信息会被保存在Configuration.incompleteStatements
   this.parsePendingStatements();
}
```
### cache解析
&emsp;&emsp;MyBatis拥有非常强大的二级缓存功能，默认情况下时没有开启二级缓存的，如果要以某命名空间开启二级缓存功能，则需要在相应的映射配置文件中添加cache节点或者cacheRef节点指定一个已存在的缓存，详情见[MyBatis源码分析-缓存模块](http://www.raocloud.cn/articles/2019/09/27/1569567839562.html 'MyBatis源码分析-缓存模块')。XMLMapperBuilder.cacheElement方法负责解析cache节点，具体实现代码如下:

```
private void cacheElement(XNode context) {
    if (context != null) {
        // 获取type属性，默认值为PERPETUAL，并查找type属性值对应的Cache接口实现
        String type = context.getStringAttribute("type", "PERPETUAL");
        Class<? extends Cache> typeClass = this.typeAliasRegistry.resolveAlias(type);
        // 获取eviction属性，默认值为LRU，并获取eviction属性值对应的装饰器，为type属性对应的实现提供装饰
        String eviction = context.getStringAttribute("eviction", "LRU");
        Class<? extends Cache> evictionClass = this.typeAliasRegistry.resolveAlias(eviction);
        Long flushInterval = context.getLongAttribute("flushInterval");
        Integer size = context.getIntAttribute("size");
        boolean readWrite = !context.getBooleanAttribute("readOnly", false);
        boolean blocking = context.getBooleanAttribute("blocking", false);
        // 获取节点下的子节点<property>，将用于初始化二级缓存，如自定义的Cache接口实现，通过<property>设置缓存文件路径
        Properties props = context.getChildrenAsProperties();
        // 通过MapperBuilderAssistant辅助类创建Cache对象，添加到Configuration.caches
        this.builderAssistant.useNewCache(typeClass, evictionClass, flushInterval, size, readWrite, blocking, props);
    }
}
```
&emsp;&emsp;MapperBuilderAssistant.userNewCache方法用来创建Cache对象和将对象保存到Configuration.caches中，caches属性类型为StrictMap，其继承了HashMap并在其基础上了做了修改，put时对检测到重复KEY则抛出异常，get时对检测到不存在的和产生二义性的key则抛出异常，具体实现自行查看源码。其中Cache对象使用CacheBuilder根据配置属性创建，CacheBuilder核心字段如下:
```
// Cache对象唯一的标识，一般情况下对应映射文件中设置的namespace  
private final String id;  
// Cache接口的真正实现类，默认值为PerpetualCache.class  
private Class<? extends Cache> implementation;  
// 装饰器集合，默认只包含LruCache.class  
private final List<Class<? extends Cache>> decorators;  
private Integer size;  
// 清理周期  
private Long clearInterval;  
// 是否可读写  
private boolean readWrite;  
// 是否阻塞  
private boolean blocking;  
// 其他配置信息  
private Properties properties;
```
CacheBuilder是Cache的建造者，其通过build方法创建Cache对象并添加合适的装饰器以及为装饰器字段初始化，具体实现代码如下:
```
public Cache build() {
    // 如果implementation字段和decorators字段为空，则设置为默认值
    this.setDefaultImplementations();
    // 通过反射方式创建Cache对象，Cache实现类需要提供一个接收String参数作为Id的构造器
    Cache cache = this.newBaseCacheInstance(this.implementation, this.id);
    // 根据<cache>下的<property>节点初始化Cache对象
    this.setCacheProperties((Cache)cache);
    // Cache对象类型为PerpetualCache，则为其遍历添加decorators集合中的装饰器进行包装
    // 如果是自定义的Cache接口实现，则不添加decorators集合中的装饰器
    if (PerpetualCache.class.equals(cache.getClass())) {
        Iterator var2 = this.decorators.iterator();

        while(var2.hasNext()) {
            // 通过反射获取参数为Cache类型的构造方法，并通过该构造方法创建装饰器
            Class<? extends Cache> decorator = (Class)var2.next();
            cache = this.newCacheDecoratorInstance(decorator, (Cache)cache);
            // 配置cache对象属性
            this.setCacheProperties((Cache)cache);
        }
    	// 根据<cache\>节点属性值添加装饰器，如clearInterval、readWrite等
        cache = this.setStandardDecorators((Cache)cache);
    } else if (!LoggingCache.class.isAssignableFrom(cache.getClass())) {
        // 如果不是LoggingCache的子类，则添加LoggingCache装饰器
        cache = new LoggingCache((Cache)cache);
    }

    return (Cache)cache;
}
```
### cache-ref解析
&emsp;&emsp;通过上节的介绍可知，在Configuration.caches中记录着namespace与Cache对象之间的对应关系，如果我们希望在MyBatis中多个namespace共享一个Cache对象，则可以使用<cache-ref\>节点进行设置。XMLMapperBuilder.cacheRefElement方法负责解析<cache-ref\>解析，具体实现代码如下:
```
private void cacheRefElement(XNode context) {
    if (context != null) {
    	// 保存当前namespace与共享Cache对象namespace对应关系至Configuration.cacheRefMap中
        this.configuration.addCacheRef(this.builderAssistant.getCurrentNamespace(), context.getStringAttribute("namespace"));
	// 创建CacheRefResolve对象，~~~~封装了被引用的namespace和当前XMLMapperBuilder对应的MapperBuilderAssistant
        CacheRefResolver cacheRefResolver = new CacheRefResolver(this.builderAssistant, context.getStringAttribute("namespace"));
        try {
            cacheRefResolver.resolveCacheRef();
        } catch (IncompleteElementException var4) {
    	    // 如果解析过程出现异常，则添加到Configuration.incompleteCacheRef中，稍后再解析
            this.configuration.addIncompleteCacheRef(cacheRefResolver);
        }
    }
}
```
&emsp;&emsp;CacheRefResolver是Cache引用解析器，其封装了被引用的namespace和当前XML映射文件对应的MapperBuilderAssistant，便于在创建Cache对象时抛出IncompleteElementException异常时稍后重新解析时信息的提取，防止再次解析XML文件浪费时间。该类只有resolveCacheRef方法，内部通过调用XMLMapperAssistant.userCacheRef方法查找被引用的namespace对应的Cache对象，userCacheRed具体实现代码如下:
```
public Cache useCacheRef(String namespace) {
    if (namespace == null) {
        throw new BuilderException("cache-ref element requires a namespace attribute.");
    } else {
        try {
    	    // 标识未成功解析cache-ref节点
            this.unresolvedCacheRef = true;
    	    // 从Configuration.caches中获取被引用的namespace对应的Cache对象
            Cache cache = this.configuration.getCache(namespace);
            if (cache == null) {
        	// 未获取到Cache对象则抛出异常
                throw new IncompleteElementException("No cache for namespace '" + namespace + "' could be found.");
            } else {
                this.currentCache = cache;
		// 标识成功解析cache-ref节点
                this.unresolvedCacheRef = false;
                return cache;
            }
        } catch (IllegalArgumentException var3) {
            throw new IncompleteElementException("No cache for namespace '" + namespace + "' could be found.", var3);
        }
    }
}
```
### resultMap解析  
&emsp;&emsp;在JDBC编程中，为了将结果集中的数据映射成对象，我们需要自己写代码从结果集中获取数据，然后封装成对应的对象并设置对象之间的关系，这些操作存在大量的重复性代理。为了减少重复性代码，在MyBatis使用<resultMap\>节点定义了结果集与结果对象直接的映射规则，其可以满足绝大多数的映射需求，从而减少开发人员的重复性工作，提高开发效率。
#### ResultMap和ResultMapping
&emsp;&emsp;在解析过程中使用到两个数据结构用于存储结果集与结果对象的映射关系，分别为ResultMap和ResultMapping。ResultMap用于存储<resultMap\>节点以及映射关系等所有信息，ResultMapping用于存储数据库列与被映射对象字段的映射规则(即<resultMap\>子节点)，其中ResultMap核心字段如下:
```
// 对应节点的id属性，默认值为父节点的id或value或property属性值的拼接  
private String id;  
// 对应节点的type属性，表示将被映射成type执行类型对象全限定名  
private Class<?> type;  
// 记录了除了<discriminator>节点之外的其他映射关系节点集合  
private List<ResultMapping> resultMappings;  
// 记录了映射关系中带有ResultFlag.ID标识的映射关系，例如<id\>节点和<constructor>节点的<idArg>子节点  
private List<ResultMapping> idResultMappings;  
// 记录了映射关系中带有ResultFlag.CONSTRUCTOR标志的映射关系，例如<constructor>所有的子节点  
private List<ResultMapping> constructorResultMappings;  
// 记录了映射关系中不带有ResultFlag.CONSTRUCTOR标志的映射关系  
private List<ResultMapping> propertyResultMappings;  
// 记录了所有映射关系中column属性值  
private Set<String> mappedColumns;  
// 记录了所有映射关系中的property属性值  
private Set<String> mappedProperties;  
// 鉴别器，对应<discriminator\>节点  
private Discriminator discriminator;  
// 是否含有嵌套的结果映射，如果某个映射关系中存在resultMap属性，且不存在resultSet属性，则为true  
private boolean hasNestedResultMaps;  
// 是否含有嵌套查询，如果某个映射关系中存在select属性，则为true  
private boolean hasNestedQueries;  
// 是否开启自动映射  
private Boolean autoMapping;
```
除了<discriminator\>节点外，其他所有子节点会被解析成ResultMapping对象，ResultMapping核心字段如下:
```
// 对应节点的property属性，表示与该列进行映射的属性  
private String property;  
// 对应节点的column属性，表示的是从数据中得到的列名或者列的别名  
private String column;  
// 对应节点的javaType属性，表示的是一个JavaBean的完全限定名或者别名  
private Class<?> javaType;  
// 对应节点的jdbcType属性，表示的是进行映射的列的JDBC类型  
private JdbcType jdbcType;  
// 对应节点的typeHandler属性，表示类型处理器，会覆盖默认的类型处理器  
private TypeHandler<?> typeHandler;  
// 对应节点的resultMap属性，该属性通过id引用另外一个<resultMap>节点定义，将结果集中的一部分映射成其他关联的结果对象  
private String nestedResultMapId;  
// 对应节点的select属性，该属性通过id应用另外一个<select>节点定义，它会把指定的列值作为select语句的入参  
// 会导致N+1问题，但是可以使用懒加载机制作为该问题的解决方案  
private String nestedQueryId;  
// 对应节点的notNullColumn属性拆分后的结果，表示的是被映射的列至少一个不为空时才创建子对象  
private Set<String> notNullColumns;  
// 对应节点的columnPrefix属性，连接查询时可能会产生相同的列名，该属性允许你将带有这些前缀的列映射到一个外部的结果映射中  
private String columnPrefix;  
// 处理后的标志，标志共有两个: id 和 Constructor  
private List<ResultFlag> flags;  
// 对应节点的column属性拆分后生成的结果，例如column={name="", age=""}，大小大于0时，column值为null，该方式一般用于和select属性搭配使用  
private List<ResultMapping> composites;  
// 对应节点的resultSet属性，用于加载复杂类型的结果集名称，例如返回的结果集有多个resultSet="blog,author"  
private String resultSet;  
// 对应节点的foreignColumn属性，表示的是外键对应的列名，将于父类型中column的列进行匹配  
private String foreignColumn;  
// 对应节点的fetchType属性，标示的是是否延迟加载  
private boolean lazy;
```
#### 解析过程
&emsp;&emsp;XMLMapperBuilder.resultMapperElement负责循环解析映射文件中全部<reusltMap\>节点以及匿名嵌套映射列表来创建ResultMap对象并添加到Configuration.resultMaps中，每个<resultMap\>节点对应的ResultMap对象在Configuration.resultMaps中保存了两份，一份是id+ResultMap，另一份是namespace.id+ResultMap，具体实现代码如下:
```
private ResultMap resultMapElement(XNode resultMapNode, List<ResultMapping> additionalResultMappings, Class<?> enclosingType) throws Exception {  
    ErrorContext.instance().activity("processing " + resultMapNode.getValueBasedIdentifier());  
    // 当节点id属性不存在时，此时代表着<association>、<collection>等节点，解析的是嵌套映射列表，
    // 其id值自动生成，为所有父节点的名称+id或者value或propertu属性值的拼接，例如mapper_resultMap[userResultMap]_collection[address]  
    String id = resultMapNode.getStringAttribute("id", resultMapNode.getValueBasedIdentifier());  
    // resultMapNode为<resultMap>节点时获取type，为<association>节点时获取javaType ，resultMapNode为<collection>节点时获取ofType属性值  
    String type = resultMapNode.getStringAttribute("type", resultMapNode.getStringAttribute("ofType", resultMapNode.getStringAttribute("resultType", resultMapNode.getStringAttribute("javaType"))));  
    // 当节点为<resultMap>时获取节点extends属性值，指定了继承关系  
    String extend = resultMapNode.getStringAttribute("extends"); 
    // 当节点为<resultMap>时获取节点的autoMapping属性值，  
    // 属性设置为true时表示启动自动映射功能，自动查找与列名相同的映射对象的字段，并调用setter方法  
    // 属性设置为false时表示需要在<id>或者<result>明确设置映射关系才会调用setter方法  
    Boolean autoMapping = resultMapNode.getBooleanAttribute("autoMapping");  
    Class<?> typeClass = this.resolveClass(type);  
    if (typeClass == null) {  
        // 自动推断映射对象类型，enclosingType为父节点的映射对象类型
        // resultMapNode为<association>时，会根据property和enclosingType推断当前嵌套映射列表被映射成的对象类型  
        // resultMapNode为<case>时，会直接返回enclosingType，表示映射列表在就在enclosingType类型字段中  
        typeClass = this.inheritEnclosingType(resultMapNode, enclosingType);  
    }  
    .............局部变量定义，以下为解析<resultMap\>子节点或者嵌套映射列表
    while(var12.hasNext()) {  
        XNode resultChild = (XNode)var12.next();  
        if ("constructor".equals(resultChild.getName())) {  
            // 处理<constructor>节点，为子节点添加ResultFlag.CONSTRUCTOR/ID标识后调用buildResultMappingFromContext创建ResultMapping对象  
            this.processConstructorElement(resultChild, typeClass, resultMappings);  
        } else if ("discriminator".equals(resultChild.getName())) {  
            // 处理<discriminator>节点，通过调用MapperBuilderAssistant.buildDiscriminator创建Discriminator对象
	    // 所有<case>节点会被解析成一个Map，其中KEY为value属性，VALUE为resultMap属性
	    // 如果resultMap属性不存在则尝试去解析嵌套映射列表
            discriminator = this.processDiscriminatorElement(resultChild, typeClass, resultMappings);  
        } else {  
            // 处理<id>、<result>、<association>等节点  
            List<ResultFlag> flags = new ArrayList();  
            if ("id".equals(resultChild.getName())) {  
                // 如果是<id>节点，则为节点添加ResultFlag.ID标识  
                flags.add(ResultFlag.ID);  
            }  
            // 创建ResultMapping对象，并添加到resultMappings中
            resultMappings.add(this.buildResultMappingFromContext(resultChild, typeClass, flags));  
        }  
    }  
    // 创建ResultMapResolver，封装了当前xml映射文件对应的MapperBuilderAssistant对象等信息  
    ResultMapResolver resultMapResolver = new ResultMapResolver(this.builderAssistant, id, typeClass, extend, discriminator, resultMappings, autoMapping);  
  
    try {  
        // 创建ResultMap对象，并添加Configuration.resultMaps中，resultMaps类型为StrictMap类型  
        return resultMapResolver.resolve();  
    } catch (IncompleteElementException var15) {  
	// 创建ResultMap对象失败，将ResultMapResolve对象保存至Configuration.incompleteResultMap中
        this.configuration.addIncompleteResultMap(resultMapResolver);  
        throw var15;  
    }  
}
```
在执行获取到当前节点的id、type等属性后，通过调用XMLMapperBuilder.buildResultMappingFromContext方法为其子节点创建对应ResultMapping对象，具体实现代码如下:
```
private ResultMapping buildResultMappingFromContext(XNode context, Class<?> resultType, List<ResultFlag> flags) throws Exception {  
    String property;  
    if (flags.contains(ResultFlag.CONSTRUCTOR)) {  
        // 包含ResultFlag.CONSTRUCTOR标识，表示为<constructor>节点子节点  
        // <idArg column="id" javaType="int" name="id" />  
        property = context.getStringAttribute("name");  
    } else {  
        // <result property="title" column="blog_title"/>  
        property = context.getStringAttribute("property");  
    }  
  
    .........获取column、javaType、jdbcType、select代码同上  
    // 获取resultMap属性值，未设置该属性时则通过processNestedResultMappings尝试解析嵌套映射列表  
    String nestedResultMap = context.getStringAttribute("resultMap", this.processNestedResultMappings(context, Collections.emptyList(), resultType));  
    .........获取notNullColumn、columnPrefix、typeHandler、resultSet、foreignColumn代码同上  
    // 获取fetchType属性值，判断是否为懒加载，默认值与全局配置一样，在mybatis-config.xml文件中配置lazyLoadingEnabled参数设置全局懒加载  
    boolean lazy = "lazy".equals(context.getStringAttribute("fetchType", this.configuration.isLazyLoadingEnabled() ? "lazy" : "eager"));  
    Class<?> javaTypeClass = this.resolveClass(javaType);  
    Class<? extends TypeHandler<?>> typeHandlerClass = this.resolveClass(typeHandler);  
    JdbcType jdbcTypeEnum = this.resolveJdbcType(jdbcType);  
    // 创建ResultMapping对象  
    return this.builderAssistant.buildResultMapping(resultType, property, column, javaTypeClass, jdbcTypeEnum, nestedSelect, nestedResultMap, notNullColumn, columnPrefix, typeHandlerClass, flags, resultSet, foreignColumn, lazy);  
}
```
如果节点未设置resultMap属性，则尝试通过调用processNestedResultMappings方法解析匿名的嵌套映射列表，嵌套映射列表只存在于<association\>、<collection\>以及<case\>中，具体实现代码如下:
```
private String processNestedResultMappings(XNode context, List<ResultMapping> resultMappings, Class<?> enclosingType) throws Exception {  
    // 获取嵌套列表对应ResultMap唯一标识，指定了select属性不会生成嵌套ResultMap对象  
    if (("association".equals(context.getName()) || "collection".equals(context.getName()) || "case".equals(context.getName())) && context.getStringAttribute("select") == null) {  
        // 校验<collection>节点的property属性在enclosingType是否存在setter方法，不存在则抛出异常  
        this.validateCollection(context, enclosingType);  
        // 解析嵌套映射列表创建ResultMap对象，该对象的ID为自动生成的，例如mapper_resultMap[blogResultMap]_association[author]  
        ResultMap resultMap = this.resultMapElement(context, resultMappings, enclosingType);  
        return resultMap.getId();  
    } else {  
        return null;  
    }  
}
```
解析<resultMap\>子节点获取到ResultMapping对象集合后，会调用ResultMapResolver.resolve方法，该方法会调用MapperBuild而Assistant.addResultMap方法创建ResultMap对象，并将对象保存到Configuration.resultMaps中。在创建对象之前会对extends属性进行校验，当父<resultMap\>与子<resultMap\>都包含<constructor\>时，会删除父<resultMap\>的<constructor\>相关节点，具体实现代码如下:
```
public ResultMap addResultMap(String id, Class<?> type, String extend, Discriminator discriminator, List<ResultMapping> resultMappings, Boolean autoMapping) {  
    // 拼接namespace和id，ResultMap完整ID为"namespace.id"格式  
    id = this.applyCurrentNamespace(id, false);  
    // 获取被继承的ResultMap的完整id，如果被继承的resultMap不是在同一namespace时，  
    // 需要以targetNamespace.targetResultMap方式指定，或者被继承的resultMap只能在同一namespace  
    extend = this.applyCurrentNamespace(extend, true);  
    ResultMap resultMap;  
    if (extend != null) {  
        if (!this.configuration.hasResultMap(extend)) {  
            // 如果不存在抛出IncompleteElementException，稍后重新创建ResultMap对象  
            throw new IncompleteElementException("Could not find a parent resultmap with id '" + extend + "'");  
        }  
  
        resultMap = this.configuration.getResultMap(extend);  
        List<ResultMapping> extendedResultMappings = new ArrayList(resultMap.getResultMappings());  
        // 删除需要覆盖的ResultMappings  
        extendedResultMappings.removeAll(resultMappings);  
        // 记录当前<resultMap>是否定义了<constructor>节点  
        boolean declaresConstructor = false;  
        Iterator extendedResultMappingsIter = resultMappings.iterator();  
        while(extendedResultMappingsIter.hasNext()) {  
            ResultMapping resultMapping = (ResultMapping)extendedResultMappingsIter.next();  
            if (resultMapping.getFlags().contains(ResultFlag.CONSTRUCTOR)) {  
                declaresConstructor = true;  
                break;  
            }  
        }  
        // declaresConstructor为true则删除父<resultMap>的<constructor>  
        if (declaresConstructor) {  
            extendedResultMappingsIter = extendedResultMappings.iterator();  
            while(extendedResultMappingsIter.hasNext()) {  
                if (((ResultMapping)extendedResultMappingsIter.next()).getFlags().contains(ResultFlag.CONSTRUCTOR)) {  
                    extendedResultMappingsIter.remove();  
                }  
            }  
        }  
        // 添加需要虚继承的ResultMapping  
        resultMappings.addAll(extendedResultMappings);  
    }  
    // 创建ResultMap对象  
    resultMap = (new org.apache.ibatis.mapping.ResultMap.Builder(this.configuration, id, type, resultMappings, autoMapping)).discriminator(discriminator).build();  
    // 添加到Configuration.resultMaps  
    this.configuration.addResultMap(resultMap);  
    return resultMap;  
}
```
### sql解析
&emsp;&emsp;在映射文件中，可以使用<sql\>节点定义可重用的SQL语句片段，当需要重用<sql\>节点中定义的SQL语句片段时，只需要使用<include\>节点引入相应的片段即可，这样在编写SQL语句以及维护这些SQL语句时，都会比较方便。XMLMapperBuilder.sqlElement方法负责解析映射配置文件中定义的全部<sql>节点并保存到Configuration.sqlFragments中，具体实现代码如下:
```
private void sqlElement(List<XNode> list, String requiredDatabaseId) {
    Iterator var3 = list.iterator();

    while(var3.hasNext()) {
        XNode context = (XNode)var3.next();
	// 获取databaseId属性
        String databaseId = context.getStringAttribute("databaseId");
	// 获取id属性，并为id添加namespace
        String id = context.getStringAttribute("id");
        id = this.builderAssistant.applyCurrentNamespace(id, false);
	// 检测<sql>的databaseId与当前Configuration中的记录的databaseId是否一致
        if (this.databaseIdMatchesCurrent(id, databaseId, requiredDatabaseId)) {
	    // XMLMapperBuilder.sqlFragments指向了Configuration.sqlFragments
            this.sqlFragments.put(id, context);
        }
    }
}
```
