title: MyBatis源码分析-缓存模块
date: '2019-09-27 15:03:59'
updated: '2019-10-10 10:32:19'
tags: [MyBatis, 缓存]
permalink: /articles/2019/09/27/1569567839562.html
---
## 前言
&emsp;&emsp;Mybatis作为一个持久化框架，内置了强大的事务性查询缓存机制，可以非常方便地配置和定制，根据缓存作用域的不同，缓存可以分为两种类型 : 一级缓存和二级缓存 :
* 一级缓存 : 也叫会话缓存，其作用域为SqlSession，不同的SqlSession之间的缓存数据互不影响，当SqlSession结束后该缓存数据会被销毁。默认开启
* 二级缓存 : 也叫全局缓存，其作用域为Mapper，多个SqlSession之间可以共享缓存，当SqlSession结束后该缓存数据还存在，并且缓存是事务性的，当SqlSession完成并提交或者完成并回滚时，但是没有执行flushCache=true的insert/update/delete语句时，缓存数据会获得更新

## 配置方式
&emsp;&emsp;MyBatis的二级缓存默认是不开启的，需要手动在XML映射配置文件中进行配置<cache\>才能开启，需要注意的是缓存只作用于<cache\>所在的XML映射配置文件中的语句，如果XMl映射配置文件对应的Mapper接口中存在注解，在接口中的语句将不会被默认缓存，需要使用@CacheNamespaceRef注解指定缓存作用域，配置方式如下:
```
<cache eviction="FIFO" flushInterval="60000" size="512" readonly="true" \>
或者
<cache-ref namespace="指定已存在的namespace"\>
```
其语句产生效果如下 :
* 映射配置文件中所有select语句的查询结果都将会被缓存
* 映射配置文件中所有insert、update和delete语句会刷新缓存
* eviction : 缓存会使用先进先出算法(FIFO)来淘汰缓存数据，默认值为LRU，可选淘汰策略如下 : 
	* LRU : 最近最少使用算法，移除最近最长时间不被使用的对象
	* FIFO : 先进先出算法，按对象进入缓存的顺序来移除
	* SOFT : 软引用，基于垃圾回收器状态和软引用规则移除对象
	* WEAK : 弱引用，更积极的基于垃圾回收器状态和弱引用规则移除对象
* flushInterval : 缓存定期60s进行刷新一次。默认值为没有刷新间隔，缓存仅仅会在调用语句时被刷新
* size : 缓存会保存列表或者对象的512个引用。默认值为1024
* readonly : 缓存会被视为只读缓存。默认值为false，只读缓存会给所有调用者返回缓存对象的相同实例，可读写缓存会返回缓存对象的深拷贝

注意：在insert/update/delete/select标签上指定属性flushCache(默认为true)设置是否在被调用后刷新会话缓存和二级缓存，select标签上指定属性useCache(默认为true)设置是否在被调用后缓存查询结果

## Cache接口
&emsp;&emsp;Cache接口是MyBatis缓存模块中最核心的接口，定义了所有缓存的基本行为。其实现类只有PerpetualCache提供了Cache接口的基本实现，内部通过维护一个Map来保存缓存数据，其他实现类都是装饰器([设计模式-装饰器模式](http://www.raocloud.cn/articles/2019/09/27/1569567958843.html))，这些装饰器在PerpetualCache的基础上提供了一些额外的功能，通过组合多个装饰器来满足一个特定的需求，如缓存数据淘汰策略。Cache接口定义如下 :
```
public interface Cache {
    // 该缓存对象ID
    String getId();
    // 向缓存中添加数据，一般情况下，KEY为CacheKey，VALUE为查询结构
    void putObject(Object var1, Object var2);
    // 根据指定的KEY，在缓存中查找对应的结果对象
    Object getObject(Object var1);
    // 删除KEY对应的缓存项
    Object removeObject(Object var1);
    // 情况缓存
    void clear();
    // 缓存项个数，该方法不会被MyBatis核心代码使用，所以可提供空实现
    int getSize();
    // 获取读写锁，该方法不会被MyBatis核心代码使用，所以可提供空实现
    ReadWriteLock getReadWriteLock();
}
```
### LruCache
&emsp;&emsp;淘汰策略“LRU”根据最近最少使用算法来清除缓存项，对应的装饰器为LruCache，内部通过额外维护一个LinkedHashMap对象保存已缓存的KEY，LinkedHashMap对象被设置为按照访问顺序排序(accessOrder=true)，当访问缓存项时，保存在LinkedHashMap对应的KEY会被移动到双向链表的尾部，当缓存项达到上限时移除并返回最近最少使用的节点(head后的那个节点)，然后调用委托Cache对象的removeObject方法删除对应的缓存项，其核心实现代码如下 :
```
// 底层被装饰的Cache对象
private final Cache delegate;
// LinkedHashMap类型对象，用于记录KEY最近的使用情况
private Map<Object, Object> keyMap;
// 记录最少被使用的缓存项的KEY
private Object eldestKey;

public void setSize(final int size) {
	// accessOrder被设置为true，按照访问顺序排序，在调用LinkedHashMap.get()方法时会改变元素的顺序
        this.keyMap = new LinkedHashMap<Object, Object>(size, 0.75F, true) {
            private static final long serialVersionUID = 4267176411845948333L;
	    // 调用LinkedHashMap.put方法时会调用该方法
            protected boolean removeEldestEntry(Entry<Object, Object> eldest) {
                boolean tooBig = this.size() > size;
                if (tooBig) {
		    // 如果已达到缓存上限则更新eldestKey字段，后面会删除该缓存项
                    LruCache.this.eldestKey = eldest.getKey();
                }
                return tooBig;
        }
    };
}
public void putObject(Object key, Object value) {
    this.delegate.putObject(key, value);
    // 校验并删除最久未使用的缓存项
    this.cycleKeyList(key);
}

public Object getObject(Object key) {
    // 将当前访问的缓存项KEY移动到LinkedHashMap的双向链表末尾
    this.keyMap.get(key);
    return this.delegate.getObject(key);
}
private void cycleKeyList(Object key) {
    this.keyMap.put(key, key);
    if (this.eldestKey != null) {
	// eldestKey不为空，表示缓存已达到上线，删除最久未使用的缓存项
        this.delegate.removeObject(this.eldestKey);
        this.eldestKey = null;
    }
}
```
### FifoCache
&emsp;&emsp;淘汰策略“FIFO”根据先进先出的算法来清除缓存项，对应的装饰器为FifoCache，内部通过额外维护一个LinkedList对象保存已缓存的KEY，当缓存项达到上限时移除并返回LinkedList的头节点，然后调用委托Cache对象的removeObject方法删除对应的缓存项，其核心实现代码如下 :
```
// 底层被装饰的Cache对象
private final Cache delegate;
// 用于记录KEY进入缓存的先后顺序，使用的是LinkedList<Object>类型的集合对象
private final Deque<Object> keyList;
// 记录缓存项的上限，超过该值则需要清理老的缓存项
private int size;

public void putObject(Object key, Object value) {
    // 检测并清理老的缓存项
    this.cycleKeyList(key);
    // 添加缓存项
    this.delegate.putObject(key, value);
}
private void cycleKeyList(Object key) {
    // 记录缓存KEY
    this.keyList.addLast(key);
    // 如果达到缓存上限，则清理最老的缓存项
    if (this.keyList.size() > this.size) {
        Object oldestKey = this.keyList.removeFirst();
        this.delegate.removeObject(oldestKey);
    }

}
```

### CacheKey
&emsp;&emsp;在Cache通过KEY来唯一确定缓存对象，由于MyBatis中涉及到动态SQL语句等因素，其缓存项不能仅仅通过SQL语句来表示，正因如此，MyBatis提供了CacheKey类来表示缓存对象的KEY，其核心字段如下 :
```
// 参与计算hashcode
private final int multiplier;
// CacheKey对象的hashcode
private int hashcode;
// 校验和
private long checksum;
// updateList集合的个数
private int count;
// 有该集合中的所有对象共同决定两个CacheKey是否相同
private List<Object> updateList;
```
其中updateList集合包含如下四个部分 :
* MappedStatement的ID，即namespace+"."+id
* 指定查询结果集的范围，也就是RowBounds.offset和RowBounds.limit
* 查询所使用的SQL语句，也就是boundSql.getSql方法返回的SQL语句，其中可能包含"?"占位符
* 用户传递的参数值

## 自定义缓存
&emsp;&emsp;不管是一级缓存还是二级缓存，其缓存数据行为都是通过使用MyBatis提供的Cache接口实现类来实现的，当MyBatis默认实现PerpetualCache不满足业务需求时，可以实现自己的缓存或为其他第三方缓存方案创建适配器来完全覆盖默认的缓存行为，如redis缓存方案、encache缓存方案。其配置方式如下 :
```
<cache type="cn.raocloud.cache.CustomCache">
	<!-- 为自定义缓存的传递属性值 -->
	<property name="redisTemplate" value="#{redisTemplate}"/>
</cache>
```
通过type属性指定自定义缓存的全限定路径名，需要注意的是自定义缓存必须实现org.mybatis.cache.Cache，并提供一个接收String参数作为Id的构造器
