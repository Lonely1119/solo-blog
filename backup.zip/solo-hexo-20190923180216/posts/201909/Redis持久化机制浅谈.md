title: Redis持久化机制浅谈
date: '2019-09-23 16:46:59'
updated: '2019-09-23 17:34:56'
tags: [redis]
permalink: /articles/2019/09/23/1569228419349.html
---
## 持久化
  Redis 支持两种持久化方式，分别为 RDB 和 AOF，持久化功能有效的避免进程退出造成的数据丢失问题，在故障恢复重启服务器时可以根据持久化文件进行数据恢复。

### RDB 方式
  RDB 持久化就是把当前进程数据生成快照文件(*.rdb)保存到硬盘中过程，RDB 文件是一个压缩的二进制文件，代表这某个时间点上的数据快照，在 Redis 版本更新的过程中，RDB 文件格式有多个版本，存在着老版本 Redis 服务器无法兼容新版本 RDB 格式的问题。

#### 触发机制
  触发 RDB 持久化过程有两种方式，分别为手动触发和自动触发。其中手动触发对应的命令有两种，分别为 save 和 bgsave:
* save 命令: 阻塞当前 Redis 进程，直到 RDB 持久化过程完成为止，进程阻塞期间不接受任何读写请求。
* bgsave 命令: Redis 进程执行 fork 操作创建子进程，RDB 持久化过程由子进程负责，持久化完成后自动结束。阻塞只发生在 fork 阶段。

除了手动触发之外，Redis 还存在自动触发机制:
* 开启 save 配置参数: 如<save m n>表示 m 秒内数据集存在 n 次修改时会自动触发 bgsave。
* 从节点执行全量复制操作，主节点自动执行 bgsave 生成 RDB 文件并发送给从节点。
* 默认情况下执行 shutdown 命令时，如果没有开启 AOF 持久化功能则自动执行 bgsave。

#### 执行过程
* 执行 bgsave 命令，父进程判断当前是否存在正在执行的持久化操作的子进程，如果存在则直接返回;
* 父进程执行 fork 操作创建子进程，fork 操作执行时会阻塞父进程;
* 父进程 fork 操作完成后，bgsave 命令返回“Background saving started”信息，并且不再阻塞父进程;
* 子进程根据父进程内存临时快照文件，创建 RDB 文件，完成后对原有文件进行原子替换;
* 子进程发送信号给父进程表示完成持久化操作，父进程更新统计信息

涉及到的持久化状态描述的命令以及选项含义:
```
info stats: 记录一般统计信息
    latest_fork_usec: 最近一次fork操作耗费的毫秒数
    
info persistence: 记录了RDB/AOF持久化有关信息
    loading: 记录了服务器是否正在载入持久化文件
    rdb_bgsave_in_progress: 记录了服务器是否正在创建RDB文件
    rdb_changes_since_last_save: 记录了距离最近一次成功创建持久化文件之后，经过了多少秒
    rdb_last_save_time: 记录了最后一次成功创建RDB文件的UNIX时间戳
    rdb_last_bgsave_time_sec: 记录了最近一次创建RDB文件耗费的秒数
    rdb_last_bgsave_status: 记录了最近一次创建RDB文件的结果是成功还是失败
    rdb_current_bgsave_time_sec: 如果服务器正在创建RDB文件，那么这个记录就是当前的创建操作已经耗费的秒数
```

#### RDB 优缺点

* RDB 的优点:
> RDB 是一个非常紧凑的二进制文件，代表着 Redis 在某个时间点上的数据快照，例如你可以在最近的 24 小时内每小时存档一次 RDB 文件，并在 30 天内每天保一次 RDB 文件，这使得你在灾难情况下轻松还原数据集的不同版本
可以 RDB 文件传输到远程机器或者文件系统，用于灾难恢复
Redis 加载 RDB 恢复数据远远快于 AOF 方式

* RDB 的缺点:
> RDB 持久化方式无法做到实时/秒级持久化，因为持久化操作每次都需要执行 fork 操作，属于重量级操作，频繁执行成本过高，如果数据及比较大可能会
导致 Redis 服务器在一段时间内不能为客户端提供服务

RDB 文件格式存在多个版本，可能存在版本不兼容的问题

### AOF 方式

  AOF 持久化以独立日志的方式记录每次写命令，重启时在重新执行 AOF 文件中的命令达到恢复数据目的，主要为了解决数据持久化的实时性问题。
AOF 文件内容直接是文本协议格式，使得其具有很好的兼容性和可读性，同时由于命令都是以追加的方式写入文件中，所以采用文本协议避免了二次处理开销。

```
格式: *3\r\n$3\r\nset\r\n$5\r\nhello\r\n$5\r\nworld\r\n
解释: 
    \r\n: 每行的结束符
    *3(*+数字): 参数个数，这里为3个，分别为set、hellow、word
    $3/$5($+数字): 参数长度
    set/hello/world: 参数具体值
```

#### 触发机制

  开启 AOF 功能需要在配置文件中进行配置，默认是不开启的，配置参数如下:

```
appendonly(默认为no): 配置是否开启AOF持久化功能
appendfilename(默认为appendonly.aof): 配置AOF文件名称
dir: 配置AOF文件存储位置(RDB和AOF存储位置一样)
或者通过在线设置: 
config set appendonly yes
```

#### 执行流程

* 所有写入命令会追加到 aof_buf(缓冲区)中
* AOF 缓冲区根据设置的文件同步策略向硬盘做同步操作
* AOF 文件大小到达配置的重写条件，则对 AOF 文件进行重写操作，达到压缩的目的
* 服务器重启时，加载 AOF 文件进行数据恢复

##### 同步策略

  Redis 提供了多种 AOF 缓冲区同步文件策略，可以在配置文件中通过 appendfsync 进行设置，其只有三种选择: always、everysec 以及 no，其
中 exerysec 为默认值:

* always: 命令写入 aof_buf 后调用系统 fsync 操作同步到 AOF 文件，fsync 完成后线程返回。每次写入都要同步到 AOF 文件，严重影响了 Redis 性能
* no: 命令写入 aof_buf 后调用系统 write 操作，不对 AOF 文件做 fsync 调用，同步硬盘操作由操作系统负责。由于每次同步 AOF 文件周期不可控，并且会
加大每次同步硬盘的数据量，虽然提升了性能，但是数据安全性无法保证
* everysec: 命令写入 aof_buf 后调用系统 write 调用，write 完成后线程返回，fsync 同步文件操作由专门的线程每秒调用一次。在理论情况下系统宕
机的情况下丢失 1 秒的数据

同步文件操作涉及到 write 和 fsync 两个系统调用:

* write: Linux 在内核提供页面缓存去用来提供硬盘 IO 性能，write 操作将 AOF 缓冲区数据写入到内核缓冲区后直接返回，同步硬盘操作依赖于系统调度机
制，例如：缓冲区页空间满了或者到达特定时间周期，如果此时系统宕机，缓冲区内数据将丢失
* fsync: fsync 将阻塞直到 AOF 缓冲区内的数据写入硬盘完成后返回，保证了数据持久化

##### 重写机制


### 参考
* https://redis.io/topics/persistence
* http://oldblog.antirez.com/post/redis-persistence-demystified.html
* 书籍：Redis开发与运维(付磊)
