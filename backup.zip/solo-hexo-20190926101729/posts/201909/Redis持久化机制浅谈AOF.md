title: Redis持久化机制浅谈-AOF
date: '2019-09-24 09:46:53'
updated: '2019-09-24 23:02:39'
tags: [redis]
permalink: /articles/2019/09/24/1569289613141.html
---
## AOF

  AOF 持久化以独立日志的方式记录每次写命令，服务器重启时再重新执行 AOF 文件中的命令达到恢复数据目的，主要为了解决数据持久化的实时性问题。AOF 文件内容直接是文本协议格式，使得其具有很好的兼容性和可读性，同时由于命令都是以追加的方式写入文件中，所以采用文本协议有效的避免了二次处理开销。

```
格式: *3\r\n$3\r\nset\r\n$5\r\nhello\r\n$5\r\nworld\r\n
解释: 
    \r\n: 每行的结束符
    *3(*+数字): 参数个数，这里为3个，分别为set、hellow、word
    $3/$5($+数字): 参数长度
    set/hello/world: 参数具体值
```

#### 触发机制

  开启 AOF 功能需要在配置文件中进行配置，默认是不开启的，配置参数如下:

```
appendonly(默认为no): 配置是否开启AOF持久化功能
appendfilename(默认为appendonly.aof): 配置AOF文件名称
dir: 配置AOF文件存储位置(RDB和AOF存储位置一样)
或者通过在线设置: 
config set appendonly yes
```

#### 执行流程

* 所有写入命令会追加到 aof_buf(缓冲区)中
* AOF 缓冲区根据设置的文件同步策略向硬盘做同步操作
* AOF 文件大小达到配置的重写条件或者手动触发，则对 AOF 文件进行重写操作，达到压缩的目的
* 服务器重启时，加载 AOF 文件进行数据恢复，AOF文件大小会影响数据恢复速度

涉及到的持久化状态描述的命令以及选项含义:

```
info persistence: 记录了RDB/AOF持久化有关信息
    aof_enabled: 记录了AOF是否处于打开状态
    aof_rewrite_in_progress: 记录了服务器是否正在创建AOF文件
    aof_rewrite_scheduled: 记录了在RDB文件创建完毕之后，是否需要执行预约的AOF重写操作
    aof_last_rewrite_time_sec: 记录了最近一次创建AOF文件耗费的市场
    aof_current_rewrite_time_sec: 记录了如果服务器正在创建AOF文件，则记录了当前创建操作已经耗费的秒数
    aof_last_bgrewrite_status: 记录了最近一次创建AOF文件的结果是成功还是失败
    aof_current_size: 记录了AOF文件当前的大小
    aof_base_size: 记录了服务器启动时或者AOF重写最近一次执行之后，AOF文件的大小
    aof_pending_rewrite: 记录了是否有AOF重写操作在等待RDB文件创建完毕后执行
    aof_buffer_length: 记录了AOF缓冲区大小
    aof_rewrite_buffer_length: 记录了AOF重写缓冲区大小
    aof_pending_bio_fsync: 后台IO队列中等待执行fsync调用数量
    aof_delayed_fsync: 被延迟的fsync调用数量，fsync操作阻塞主进程追加操作，该值会累加，可以通过该值判断该值定位AOF阻塞问题
```

#### 同步策略

  Redis 提供了多种 AOF 缓冲区同步文件策略，可以在配置文件中通过 appendfsync 进行设置，其只有三种选择: always、everysec 以及 no，其中 exerysec 为默认值:

* always: 命令写入 aof_buf 后调用系统 fsync 操作同步到 AOF 文件，同步完成后再将命令执行结果返回给客户端。每次写入命令都要同步到 AOF 文件，Redis的性能将取决于磁盘写入速度

* no: 命令写入 aof_buf 后调用系统 write 操作，不对 AOF 文件做 fsync 调用，同步硬盘操作由操作系统负责，即大多数Linux系统中每30秒提交一次。由于每次同步 AOF 文件周期不可控，并且会加大每次同步硬盘的数据量，虽然提升了性能，但是数据安全性无法保证

* everysec: 命令写入 aof_buf 后调用系统 write 调用，write 完成后线程返回，fsync 同步文件操作由专门的线程每秒调用一次并记录最近一次成功同步时间。主线程判断当前同步时间距离上一次成功同步时间是否大于2秒，是则阻塞主线程write操作直到同步完成，在理论情况下系统宕机的情况下丢失 1 秒的数据，最多丢失 2 秒数据

> 同步文件操作涉及到 write 和 fsync 两个系统调用:

* write: Linux 在内核提供页面缓存去用来提供硬盘 IO 性能，write 操作将数据写入到内核缓冲区后直接返回，同步硬盘操作依赖于系统调度机制，例如：缓冲区页空间满了或者到达特定时间周期，如果此时系统宕机，缓冲区内数据将丢失
* fsync: fsync 将阻塞其调用线程直到数据写入硬盘后返回，保证了数据持久化

> 阻塞问题定位: 

* 发生AOF追加阻塞时，Redis输出如下日志，用于记录fsync阻塞导致拖慢Redis服务的行为
```
Asynchronous AOF fsync is taking too long (disk is busy). Writing the AOF buffer
without waiting for fsync to complete, this may slow down Redis
```	
* 每当发生AOF追加阻塞时，在info presistence统计选项aof_delay_fsync指标会累加
* AOF同步最多允许2秒的延迟，当延迟发生时说明硬盘存在高负载问题，可以通过监控工具iotop定位消耗硬盘IO资源的进程
#### 重写机制

  重写过程触发分为手动触发和被动触发两种，手动触发通过执行 bgrewirteaof，自动触发根据 auto-aof-rewirte-min-size 和 auto-aof-rewrite-percentage 参数值来确定自动触发时机，执行流程如下:
<div align=center><img src="https://img.hacpai.com/file/2019/09/AOF文件重写-70427ac4.png"/></div>

* 执行重写请求，如果当前进程正在执行 AOF 重写，请求不执行立即返回；如果当前进程正在执行 bgsave 操作，则等待 bgsave 命令执行完成后再执行
* 父进程执行 fork 操作创建子进程，fork 操作执行完成后继续接受客户端请求，写命令追加到 AOF 缓冲区并根据同步策略同步到原有 AOF 文件，同时写命令会追加到 AOF 重写缓冲区中
* 子进程根据内存快照，按照命令合并规则写入到新AOF文件中，通过配置参数aof-rewrite-incremental-fsync控制每次写入文件的数据量大小
* 新 AOF 文件写入完成后，子进程发送信号给父进程，父进程更新统计信息，同时停止向旧AOF缓冲区和AOF文件追加写入命令，把 AOF 重写缓冲区的数据写入到新的 AOF 文件中
* 用新 AOF 文件替换老 AOF 文件，完成 AOF 文件重写

> 压缩规则如下:

```
1. 进程内已经过期的数据不在写入文件
2. 重写使用进程内数据直接生成的，旧AOF文件含有无效命令，如del key、hdel key等
3. 多条写命令可以合并为一个，如lpush list value1、lpush list value2合并为lpush list value1 value2等，为防止单条命令过大造成客户端缓冲区溢出，对于list、set、hash、zset等类型操作，以64个元素为界拆分为多条
```

> 涉及到的配置参数含义:

```
auto-aof-rewrite-min-size: AOF文件最小大小，触发重写条件之一
auto-aof-rewrite-percentage: 当前AOF文件大小(aof_current_size)和上一次重写后AOF文件大小(aof_base_size)的比值，触发重写调价之一
aof-rewrite-incremental-fsync: 重写时，批量写入文件数据量大小，默认为32M，防止单词刷盘数据过多导致硬盘阻塞

自动触发时机 = (aof_current_size > auto-aof-rewrite-min-size) && ((aof_current_size - aof_base_size) / aof_base_size >= auto-aof-rewirte-percentage)
```
## 参考

* [http://mysql.taobao.org/monthly/2016/03/05/](http://mysql.taobao.org/monthly/2016/03/05/)
* [https://redis.io/topics/persistence](https://redis.io/topics/persistence)
* [http://oldblog.antirez.com/post/redis-persistence-demystified.html](http://oldblog.antirez.com/post/redis-persistence-demystified.html)
* 书籍：Redis 开发与运维(付磊)~~~~
