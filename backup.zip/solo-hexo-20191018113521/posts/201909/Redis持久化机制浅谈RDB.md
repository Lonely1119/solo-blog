title: Redis持久化机制浅谈-RDB
date: '2019-09-23 16:46:59'
updated: '2019-09-27 13:14:37'
tags: [redis]
permalink: /articles/2019/09/23/1569228419349.html
---
### RDB 

  RDB 持久化就是把当前进程数据生成快照文件(*.rdb)保存到硬盘中过程，RDB 文件是一个压缩的二进制文件，代表这某个时间点上的数据快照，在 Redis 版本更新的过程中，RDB 文件格式有多个版本，存在着老版本 Redis 服务器无法兼容新版本 RDB 格式的问题。

#### 触发机制

  触发 RDB 持久化过程有两种方式，分别为手动触发和自动触发。其中手动触发对应的命令有两种，分别为 save 和 bgsave:

* save 命令: 阻塞当前 Redis 进程，直到 RDB 持久化过程完成为止，进程阻塞期间不接受客户端任何读写请求。
* bgsave 命令: Redis 进程执行 fork 操作创建子进程，持久化过程由子进程负责完成，完成之后自动结束。阻塞只发生在 fork 阶段。

除了手动触发之外，Redis 还存在自动触发机制:

* 开启 save 配置参数: 如<save m n>表示 m 秒内数据集存在 n 次修改时会自动触发 bgsave。
* 从节点执行全量复制操作，主节点自动执行 bgsave 生成 RDB 文件并发送给从节点。
* 默认情况下执行 shutdown 命令时，如果没有开启 AOF 持久化功能则自动执行 bgsave。

#### 执行过程
<div align=center><img src="https://img.hacpai.com/file/2019/09/RDB持久化流程-e3f25f96.png"/></div>

* 客户端发送 bgsave 命令给服务器，父进程判断当前是否存在正在执行的持久化操作的子进程，如果存在则直接返回;
* 父进程执行 fork 操作创建子进程，fork 操作执行时会阻塞父进程接受客户端请求;
* 父进程 fork 操作完成后，bgsave 命令返回“Background saving started”信息，并且不再阻塞父进程;
* 子进程根据父进程内存临时快照，创建 RDB 文件，完成后对原有文件进行原子替换;
* 子进程发送信号给父进程表示完成持久化操作，父进程更新统计信息

> fork系统调用

fork操作用来创建子进程，内存占用量对外表现为与父进程相同，理论上需要一倍的物理内存来完成fork操作，但是Linux系统具有COW(写时复制)技术，父子进程会共享相同的物理内存页，当父进程处理写请求时会对需要修改的页复制出一份副本完成写操作，而子进程依然读取fork事整个父进程的内存快照，所以子进程实际消耗根据持久化期间写入命令量决定。fork耗时跟父进程内存大小成正比，如果使用虚拟化技术，fork操作可能更加耗时。

> 涉及到的持久化状态描述的命令以及选项含义:

```
info stats: 记录一般统计信息
    latest_fork_usec: 最近一次fork操作耗费的毫秒数
    
info persistence: 记录了RDB/AOF持久化有关信息
    loading: 记录了服务器是否正在载入持久化文件
    rdb_bgsave_in_progress: 记录了服务器是否正在创建RDB文件
    rdb_changes_since_last_save: 记录了距离最近一次成功创建持久化文件之后，经过了多少秒
    rdb_last_save_time: 记录了最后一次成功创建RDB文件的UNIX时间戳
    rdb_last_bgsave_time_sec: 记录了最近一次创建RDB文件耗费的秒数
    rdb_last_bgsave_status: 记录了最近一次创建RDB文件的结果是成功还是失败
    rdb_current_bgsave_time_sec: 如果服务器正在创建RDB文件，那么这个记录就是当前的创建操作已经耗费的秒数
```

#### RDB 优缺点

* RDB 的优点:

> RDB 是一个非常紧凑的二进制文件，代表着 Redis 在某个时间点上的数据快照，例如你可以在最近的 24 小时内每小时存档一次 RDB 文件，并在 30 天内每天保存一次 RDB 文件，这使得你在灾难情况下轻松还原数据集的不同版本
可以 RDB 文件传输到远程机器或者文件系统，用于灾难恢复
Redis 加载 RDB 恢复数据远远快于 AOF 方式

* RDB 的缺点:

> RDB 持久化方式无法做到实时/秒级持久化，因为持久化操作每次都需要执行 fork 操作，属于重量级操作，频繁执行成本过高，如果数据及比较大可能会导致 Redis 服务器在一段时间内不能为客户端提供服务
RDB 文件格式存在多个版本，可能存在版本不兼容的问题

### 参考

* [http://mysql.taobao.org/monthly/2016/03/05/](http://mysql.taobao.org/monthly/2016/03/05/)
* [https://redis.io/topics/persistence](https://redis.io/topics/persistence)
* [http://oldblog.antirez.com/post/redis-persistence-demystified.html](http://oldblog.antirez.com/post/redis-persistence-demystified.html)
* 书籍：Redis 开发与运维(付磊)

